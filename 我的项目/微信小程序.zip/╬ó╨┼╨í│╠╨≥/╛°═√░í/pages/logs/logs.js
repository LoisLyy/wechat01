//logs.js
Page({
 data:{
   thisWeekMovieList:[{
     name:"千与千寻",
     comment:"人性的思考和爱的力量",
     imagePath:"/images/widget.png",
     isRecommended:true,
     id:1291561,
   },
   {
     name: "看不见的客人",
     comment: "无敌大反转",
     imagePath: "/images/feedback.png",
     isRecommended: false,
     id:26580232,
   },
    {
     name: "无双",
     comment: "假钞帝国",
     imagePath: "/images/form.png",
     isRecommended: false,
     id:26425063,
     }],
     currentIndex:0
     
 },
 onLoad:function(options){
   this.setData({
    currentIndex:this.data.thisWeekMovieList.length-1
   })
 },
 f0:function(event){
   
   this.setData({
     currentIndex: this.data.thisWeekMovieList.length - 1
   }) 
 },
 f1:function(event){
   var movieId = event.currentTarget.dataset.movieId
   wx.navigateTo({
     url:'/pages/route/route?id='+ movieId,
   })
 },
 onShareAppMessage:function(){
   return{
     title:"每周推荐"
   }
 }
})
