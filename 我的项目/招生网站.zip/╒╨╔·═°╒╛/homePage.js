// JavaScript source code

window.onload = function () {
    var times;
    function $(id) { return document.getElementById(id); }
    var ulimg = $("ul_img");
    var main = $("picture");    
    var arr = $("arrow");
    var left = $("arrowLeft");
    var right = $("arrowRight");
    var index;
    var count = 0;
    var diana = $("diana");
    var dians = document.getElementsByClassName("dian");
    dians[0].style.background = "white";
    function rollTime() {
        times = setInterval(function () {
            left.onclick();
            }                
        , 2000);
    }
    rollTime();
    main.onmouseover = function () {
        clearInterval(times);
    }
    main.onmouseout = function () {
        rollTime();
    }    
    function show() {
        if (count > dians.length - 1) { count = 0; }
        else if (count < 0) { num = dians.length - 1; }
        for (var i = 0; i < dians.length; i++) {
            dians[i].style.background = "";
        }
        dians[count].style.background = "white";
    }
    for (var i = 0; i < dians.length; i++) {
        dians[i].index = i;        
        dians[i].onmouseover = function () {            
            count = this.index;
            ulimg.style.transform="translate("+-1200*count+"px)";
            show();
        }        
    }
   
    left.onclick = function () {
       
        if (count == dians.length - 1) {
            count = 0;
        }
        else {
            count++;
        }
        ulimg.style.transform = "translate(" + -1200 * count + "px)";
        show();
    }
    right.onclick = function () {
        if (count ==0 ) {
            count = dians.length - 1;
        }
        else {
            count--;
        }
        ulimg.style.transform = "translate(" + -1200 * count + "px)";
        show();
        
    }
    var timer;    
    var ulImg = $("teacherimg");
    var box = $("teacher");
    var arrow = $("arr");
    var arrLeft = $("left");
    var arrRight = $("right");
    var shu = document.getElementsByClassName("jishiu");    
    var num = 3;    
    function auto() {
        timer = setInterval(function () {
            arrLeft.onclick();
        }
        , 2000);
    }
    auto();
    box.onmouseover = function () {
        clearInterval(timer);
    }
    box.onmouseout = function () {
        auto();
    }
   arrLeft.onclick = function () {

        if (num == shu.length-5) {
            num = 3;
            
        }
        else {
            num++;           
        }
        ulImg.style.transform = "translate(" + -258 * num + "px)";       
    }
    arrRight.onclick = function () {
        if (num == 3) {
            num = shu.length-5;
        }
        else {
            num--;
        }
        ulImg.style.transform = "translate(" + -258 * num + "px)";       

    }
}