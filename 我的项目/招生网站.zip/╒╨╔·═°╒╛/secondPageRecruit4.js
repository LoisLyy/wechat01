// JavaScript source code
window.onload = function () {
    var a = document.getElementsByClassName("menuSec")[4];
    a.style.background = " #B7C76F";
    a.style.color = "white";
}